﻿param(
    [string]$InstallDir = "$env:ProgramFiles\ElyctisCardMiddleware",
    [string]$ServiceName = "ElyctisCardMiddleware"
)

$ErrorActionPreference = "Stop"

function Assert-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Run this script as Administrator."
    }
}

function Find-ElyTravelDoc {
    $candidatePaths = @(
        "$env:USERPROFILE\Desktop\Application - ELY TRAVEL DOC v4.9.3\x86\Release\ELY TRAVEL DOC.exe",
        "$env:USERPROFILE\Desktop\Application - ELY TRAVEL DOC v4.9.3\x64\Release\ELY TRAVEL DOC.exe"
    )

    foreach ($path in $candidatePaths) {
        if ($path -and (Test-Path $path)) { return $path }
    }

    $searchRoots = @("C:\Users", "C:\Program Files", "C:\Program Files (x86)") | Where-Object { Test-Path $_ }
    foreach ($root in $searchRoots) {
        $found = Get-ChildItem -Path $root -Recurse -Filter "ELY TRAVEL DOC.exe" -ErrorAction SilentlyContinue |
            Sort-Object @{ Expression = { if ($_.FullName -match '\\x86\\') { 0 } else { 1 } } }, FullName |
            Select-Object -First 1
        if ($found) { return $found.FullName }
    }

    return $null
}

Assert-Administrator

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$nssm = Join-Path $root "nssm.exe"
$source = Join-Path $root "ElyctisCardMiddleware"
$exe = Join-Path $InstallDir "ElyctisCardService.exe"

if (-not (Test-Path $nssm)) { throw "Missing nssm.exe beside this installer." }
if (-not (Test-Path (Join-Path $source "ElyctisCardService.exe"))) { throw "Missing ElyctisCardMiddleware files." }

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item -Path (Join-Path $source "*") -Destination $InstallDir -Recurse -Force
Get-ChildItem -Path $InstallDir -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir "logs") | Out-Null

$configPath = Join-Path $InstallDir "appsettings.json"
$config = Get-Content $configPath -Raw | ConvertFrom-Json
$config.ListenUrl = "http://127.0.0.1:8765/"
$config.AllowedOrigin = "*"
$config.ReaderNameContains = "ELYCTIS"
$config.ScannerPortName = "COM6"
$scannerPath = Find-ElyTravelDoc
if ($scannerPath) {
    $config.ScannerAssemblyPath = $scannerPath
    Get-ChildItem -Path (Split-Path -Parent $scannerPath) -Recurse -File | Unblock-File -ErrorAction SilentlyContinue
} else {
    Write-Warning "ELY TRAVEL DOC.exe was not found. Card reading may require MRZ/CAN input until it is installed."
}
$config | ConvertTo-Json -Depth 10 | Set-Content -Path $configPath -Encoding UTF8

try {
    Set-Service SCardSvr -StartupType Automatic
    Start-Service SCardSvr -ErrorAction SilentlyContinue
} catch {
    Write-Warning "Could not start Windows Smart Card service: $($_.Exception.Message)"
}

$existing = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($existing) {
    if ($existing.Status -ne "Stopped") {
        Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
    & $nssm remove $ServiceName confirm | Out-Null
}

& $nssm install $ServiceName $exe | Out-Null
& $nssm set $ServiceName AppParameters "--headless" | Out-Null
& $nssm set $ServiceName AppDirectory $InstallDir | Out-Null
& $nssm set $ServiceName AppStdout (Join-Path $InstallDir "logs\elyctis-service.out.log") | Out-Null
& $nssm set $ServiceName AppStderr (Join-Path $InstallDir "logs\elyctis-service.err.log") | Out-Null
& $nssm set $ServiceName AppRotateFiles 1 | Out-Null
& $nssm set $ServiceName AppRotateOnline 1 | Out-Null
& $nssm set $ServiceName AppRotateBytes 10485760 | Out-Null
& $nssm set $ServiceName Start SERVICE_AUTO_START | Out-Null
& $nssm set $ServiceName AppExit Default Restart | Out-Null
& $nssm set $ServiceName DisplayName "Elyctis Card Middleware" | Out-Null

Get-Process -Name ElyCardReaderService,ElyctisCardService -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Service $ServiceName
Start-Sleep -Seconds 4

$health = Invoke-RestMethod -Uri "http://127.0.0.1:8765/health" -Headers @{ "X-Elyctis-Token" = "change-this-local-token" } -TimeoutSec 10
if ($health.success -ne $true) { throw "Health check failed." }

Write-Host "Installed $ServiceName and verified http://127.0.0.1:8765/health"
Write-Host "Reader filter: ELYCTIS"
Write-Host "Scanner path: $($config.ScannerAssemblyPath)"
